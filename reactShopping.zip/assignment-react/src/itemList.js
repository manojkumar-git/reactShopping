import React, { Component } from 'react';

class ItemList extends Component{

	constructor(props){
		super(props);
	}


	render(){

		var videoListArr = this.props.searchData;
		var videoList = videoListArr.map( (item) => {
			return ( 
				<li key={item.id} onClick={() => this.props.onAddItem(item)} >
				<div>
					<img src={item.imagePath} />
				</div>
				<div>Add Item</div>
				</li> 

				);
		})
		return (
			<div className='item_list'>
				<div className='heading'><h4>Please click on listed items to add in cart</h4></div>
				<ul>
					{videoList}
				</ul>
			</div>
		)
	}

}

export default ItemList;