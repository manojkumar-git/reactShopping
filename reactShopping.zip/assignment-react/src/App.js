import React, { Component } from 'react';
import ItemList from './itemList';
import CheckoutData from './checkout';
import ItemDetail from './itemDetail';
import '../styles/style.css';

class App extends Component{

   constructor (props){
      super(props);
      this.state = {
         'searchedData' : [],
         'selectedItems' : [],
         'totalOrder': 0
       };

   }

   componentDidMount(){
      this.setInitialData();
   }

   setInitialData (){
      var searchedData = [
         {
            'id': 'd1',
            'name': 'Red Dress For Girls',
            'imagePath': './public/images/dress1.jpg',
            'addedToCart': false,
            'price': 50,
            'quantity': 1
         },
         {
            'id': 'd2',
            'name': 'Blue Dress For Girls',
            'imagePath': './public/images/dress2.jpg',
            'addedToCart': false,
            'price': 60,
            'quantity': 1 
         },
         {
            'id': 'd3',
            'name': 'Green Dress For Girls',
            'imagePath': './public/images/dress3.jpg',
            'addedToCart': false,
            'price': 70,
            'quantity': 1
         }
      ]
      this.setState({searchedData});

      this.addItems(searchedData[0])
      
   }

   addItems (item){
      if(item.addedToCart){
         this.manageQuantity(item, 1);
         return;
      }
      item.addedToCart = true;
      var selectedItems = this.state.selectedItems;
      var totalOrder = this.state.totalOrder;
      selectedItems.push(item);
      totalOrder = totalOrder+item.price;
      this.setState({selectedItems, totalOrder})
   }

   manageQuantity (item, val){
      if(item.quantity + val < 1){
         return;
      }
      var selectedItems = this.state.selectedItems.filter(p => p);
      var totalOrder = 0;
      for(let i=0; i<selectedItems.length; i++){
         if(selectedItems[i].id === item.id){
            selectedItems[i].quantity = selectedItems[i].quantity + val;
         }
         totalOrder = totalOrder + (selectedItems[i].quantity*selectedItems[i].price)
      }
      this.setState({selectedItems, totalOrder})
   }

   manageRemoveItem(item){
      item.addedToCart = false;
      var selectedItems = this.state.selectedItems.filter(p => p.id != item.id);
      var totalOrder = this.state.totalOrder;
      totalOrder = totalOrder - (item.price*item.quantity);
      item.quantity = 1;
      this.setState({selectedItems, totalOrder})
   }


   render(){
      
      return(
         <div>
            
            <ItemList onAddItem={(selectedItem) => this.addItems(selectedItem)} searchData={this.state.searchedData} />

            <div className='item-listing-area'>
               <div className='itemList-cont'>
                  <ItemDetail items={this.state.selectedItems} onManageRemoveItem={this.manageRemoveItem.bind(this)}  onManageQuntity={this.manageQuantity.bind(this)}/>
               </div>
               
               <CheckoutData totalOrder={this.state.totalOrder} />
            </div>
         </div>
      );
   }

  
}

export default App;