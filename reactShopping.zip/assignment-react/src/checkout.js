import React, { Component } from 'react';


class CheckoutData extends Component {
	constructor (props){
		super(props);
	}

	hireMeFirst (){
		alert('Hire me first for checkout! :)')
	}

	render(){
      return(
      		<div className="checkout-data">
				<h5>Checkout Detail</h5>
            	<div> <h6>Order Total: Rs. {this.props.totalOrder}</h6></div>
				<div className='checkoutButton'><button onClick={this.hireMeFirst}>Checkout</button> </div>
            </div>
      );
   }

}


export default CheckoutData;