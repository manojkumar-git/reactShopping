import React, { Component } from 'react';

class ItemDetail extends Component {
	constructor(props){
		super(props);
	}

	render(){
   
		var currentItems = this.props.items;

		if(!currentItems || currentItems.length < 1){
			return <div> <h6>Cart is blank, Please add items.. </h6></div>;
		}

		var itemlist = currentItems.map( (item) => {
			return ( 
				<div key={item.id} className="video-detail">
					<div className="res-container">
						<div className='itemThumb'>
							<img src={item.imagePath} />
						</div>
						<div className='itemDetail'>
							<div className='itemHeader'>
								<div className='itemTitle'><h5>{item.name}</h5></div><div className='itemPrice'><h5>Price : Rs. {item.price}</h5></div>
							</div>
							<div className='manage-quantity'>
								<button onClick={() => this.props.onManageQuntity(item, -1)}>-</button><span><b>{item.quantity}</b></span><button onClick={() => this.props.onManageQuntity(item, 1)}>+</button>
							</div>
							<div className='totalPrice'> <h5>Total : Rs. {item.price*item.quantity}</h5></div>
							<div className='removeButton'><button onClick={() => this.props.onManageRemoveItem(item)}>Remove Item</button> </div>
						</div>
						
					</div>
				</div>

			);
		})
   
		
	   return (
   
		   <React.Fragment>
			   {itemlist}
		   </React.Fragment>
   
	   );
   
   };
}

export default ItemDetail;